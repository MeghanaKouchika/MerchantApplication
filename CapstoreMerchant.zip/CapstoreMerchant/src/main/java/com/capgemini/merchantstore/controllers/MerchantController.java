package com.capgemini.merchantstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.merchantstore.beans.Merchant;
import com.capgemini.merchantstore.beans.Product;
import com.capgemini.merchantstore.exceptions.MerchantNotFoundException;
import com.capgemini.merchantstore.services.IMerchantService;

@Controller
public class MerchantController {
	
	@Autowired
	IMerchantService MerchantServices;
	
	@RequestMapping(value = "merchantSignIn")
	public ModelAndView addMerchant(@ModelAttribute("merchant") Merchant merchant, @RequestParam("securityQuestion") String question, @RequestParam("type") String type) {
		System.out.println(type);
		merchant.setSecurityQuestion(question);
		merchant = MerchantServices.addMerchant(merchant);
		return new ModelAndView("homePage");
	}
	
	@RequestMapping(value = "addProductSuccessPage/{merchantId}")
	public ModelAndView addProduct(@PathVariable int merchantId,@ModelAttribute("product") Product product) {
		System.out.println(merchantId);
		Merchant merchant = new Merchant(merchantId);
		product.setMerchant(merchant);
		product = MerchantServices.addProduct(product);
		return new ModelAndView("addProductSuccessPage");
	}
	
	@RequestMapping(value="addProduct")
	public ModelAndView getAddProductPage(@ModelAttribute("product") Product product,@RequestParam("abc")int merchantId) {
		System.out.println(merchantId);
		return new ModelAndView("addProduct","merchantId",merchantId);	
	}
	@RequestMapping(value = "removedProduct")
	public ModelAndView removeProduct(@ModelAttribute("product") Product product) {
		//Product product = new Product();
		MerchantServices.removeProduct(product);
		return new ModelAndView("removeProductSuccess","product", product);
	}
	
	@RequestMapping(value = "updateSuccess")
	public ModelAndView updateProduct(@RequestParam("productId") int productId) {
		Product product = new Product();
		product = MerchantServices.getProductDetails(productId);
		return new ModelAndView("addProduct", "product",product);
	}
	
	@RequestMapping(value = "getAllProducts")
	public ModelAndView addAllProduct() {
		List<Product> product = MerchantServices.getAllProducts();
	
		return new ModelAndView("getAllProducts", "product", product);
	}
	
	public ModelAndView forgotPassword(@RequestParam("username") String username) {
		Merchant merchant = null;
		String securityQuestion = null;
		try {
			merchant = MerchantServices.getMerchant(username);
			securityQuestion = merchant.getSecurityQuestion();
			
		} catch (MerchantNotFoundException e) {
			new ModelAndView("errorPage","error",e.getMessage());
			e.printStackTrace();
		}
		return new ModelAndView("securityQuestion","merchant",securityQuestion);
	}
	
	public ModelAndView securityAnswer(@RequestParam("username") String username, @RequestParam("securityAnswer") String answer) {
		Merchant merchant = null;
		try {
			merchant = MerchantServices.getMerchant(username);
			if(merchant.getSecurityAnswer().compareTo(answer) == 0) {
				return new ModelAndView("securityAnswer","message",merchant.getPassword());
			}
		} catch (MerchantNotFoundException e) {
			new ModelAndView("errorPage","error",e.getMessage());
			e.printStackTrace();
		}
		String message = "Not a valid user";
		return new ModelAndView("InvalidUserPage","message",message);
	}
	
	@RequestMapping(value="changePassword")
	public ModelAndView changePassword(@RequestParam("abc")int merchantId, @RequestParam("oldPassword")String oldPassword, @RequestParam("newPassword")String newPassword, @RequestParam("confirmNewPassword")String confirmNewPassword ) {
		Merchant merchant = MerchantServices.getMerchantById(merchantId);
		if(merchant.getPassword().compareTo(oldPassword) == 0) {
			MerchantServices.changePassword(merchant, newPassword);
		}
		return new ModelAndView("changePasswordSuccess");
	}

}
